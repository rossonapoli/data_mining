from itemadapter import ItemAdapter
from pymongo import MongoClient
import re
from pymongo import errors

class JobparserPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_base = client.vacancies2707

    def process_item(self, item, spider):
        my_dict = dict(item)
        my_dict = self.process_vacancy(my_dict)

        collection = self.mongo_base[spider.name]
        try:
            collection.insert_one(my_dict)
        except errors.DuplicateKeyError:
            print(f"Document with id = {my_dict['_id']} is already exists")

        # item['salary'] = self.process_salary(item['salary'])
        # collection = self.mongo_base[spider.name]
        # collection.insert_one(item)
        # salary = item['salary'].text
        # print(salary)
        # print(dict)
        return item

    def process_vacancy(self, my_dict):
        salary = ''.join(my_dict['salary'])
        salary = salary.replace('\xa0', '')
        salary = salary.replace(' ', '')
        salary = salary.replace('наруки', '')
        salary = salary.replace('довычетаналогов', '')
        temp = ['0', '0', '0']

        if re.search('от', salary) and not re.search('до', salary):
            salary = salary.replace('от', '')
            regex = r'(\d+)|(\w+)'
            matches = re.findall(regex, salary)
            temp = [_ for tupl in matches for _ in tupl if _]
            temp.insert(1, '0')

        elif re.search('до', salary) and not re.search('от', salary):
            salary = salary.replace('до', '')
            regex = r'(\d+\d+)|(\w+)'
            matches = re.findall(regex, salary)
            temp = [_ for tupl in matches for _ in tupl if _]
            temp.insert(0, '0')

        elif re.search('до', salary) and re.search('от', salary):
            salary = salary.replace('от', '')
            salary = salary.replace('до', '-')
            regex = r'(\d+\d)|(\d+\d)|(\w+)'
            matches = re.findall(regex, salary)
            temp = [_ for tupl in matches for _ in tupl if _]

        regex_id = r'([0-9]{5,9})'
        object_id = re.findall(regex_id, my_dict['url'])
        _id = int(''.join(object_id))

        vac_info_full = {}
        vac_info_full['_id'] = _id
        vac_info_full['1_title'] = my_dict['name']
        vac_info_full['2_salary_min'] = temp[0]
        vac_info_full['3_salary_max'] = temp[1]
        vac_info_full['4_salary_cur'] = temp[2]
        vac_info_full['5_href'] = my_dict['url']

        try:
            vac_info_full['2_salary_min'] = int(vac_info_full['2_salary_min'])
            vac_info_full['3_salary_max'] = int(vac_info_full['3_salary_max'])
        except:
            vac_info_full['2_salary_min'] = None
            vac_info_full['3_salary_min'] = None

        for i in vac_info_full:
            try:
                vac_info_full[i] = int(vac_info_full[i])
            except:
                continue

        for i in vac_info_full:
            if vac_info_full[i] == 0:
                vac_info_full[i] = None

        return vac_info_full